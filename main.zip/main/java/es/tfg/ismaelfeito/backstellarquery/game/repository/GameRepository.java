package es.tfg.ismaelfeito.backstellarquery.game.repository;

import es.tfg.ismaelfeito.backstellarquery.game.entity.Game;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GameRepository extends JpaRepository<Game,Long> {
}
